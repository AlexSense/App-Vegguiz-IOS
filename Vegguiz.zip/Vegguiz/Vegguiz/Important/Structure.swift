//
//  Structure.swift
//  IOS
//
//  Created by Apprenant97 on 28/01/2024.
//

import SwiftUI



class User: ObservableObject {
    @Published var name : String
    var email : String
    var motDePasse : String
    @Published var imageprofil : String
    @Published var bonneReponse: Reponse?
    @Published var progression: Jauge
    @Published var selectedAnswer: Reponse
    
    init(name: String, email: String, motDePasse: String, imageprofil: String, bonneReponse: Reponse? = nil, progression: Jauge, selectedAnswer: Reponse) {
        self.name = name
        self.email = email
        self.motDePasse = motDePasse
        self.imageprofil = imageprofil
        self.bonneReponse = bonneReponse
        self.progression = progression
        self.selectedAnswer = selectedAnswer
    }
    
    func calculPointRestant() -> String {
        return "\(progression.ptsmax - progression.pts)"
    }
}

enum Diff: String {
    case facile = "Facile"
    case Normal = "Normal"
    case Difficile = "Difficile"
}

struct Categories: Identifiable {
    var id = UUID()
    var nomCat : String
    var imageCat : String
    var nomSousCat : [String]
    var boiteQuiz : [Quiz]
}

//array de cat

let cat : [Categories] = [type, aliment,defis,bienfaits]


let type = Categories(nomCat: "Les Types de Vegetarisme", imageCat: "nuagev", nomSousCat: ["Définitions", "Histoire", "Culture", "Nutrition"], boiteQuiz: [quizCat1Sous1, quizCat1Sous2, quizCat1Sous3, quizCat1Sous4])

let aliment = Categories (nomCat: "Les aliments", imageCat: "legumes", nomSousCat: ["Les proteines", "Fruits et Légumes", "Lait", "oeufs"], boiteQuiz: [quizCat1Sous1])

let defis = Categories(nomCat: "Les défis", imageCat: "lesdefis", nomSousCat: ["Les préssions", "La santé" , "L'approvisionnement", "La préparation" ], boiteQuiz: [quizCat1Sous1])

let bienfaits = Categories(nomCat: "Les bienfaits", imageCat: "emma", nomSousCat: ["L'environnement", "La Santé", "L'Ethique", "Produits locaux"], boiteQuiz: [quizCat1Sous1])



struct Quiz: Identifiable {
    var id = UUID()
    var nom: String
    var question : [Questions]
    var totalPointsGagne: Jaugeprog
    var diff: [Diff]

    var selectedQuizz : Bool
}

let quizCat1Sous1 = Quiz(nom: "Définitions", question: [question1Cat1Sous1facile, question2Cat1Sous1facile, question3Cat1Sous1facile], totalPointsGagne: jauge, diff: [.facile], selectedQuizz: false)
let quizCat1Sous2 = Quiz(nom: "Histoire", question: [question1Cat1Sous4facile, question2Cat1Sous4facile, question3Cat1Sous4facile], totalPointsGagne: jauge, diff: [.facile],selectedQuizz: false)
let quizCat1Sous3 = Quiz(nom: "Culture", question: [question1Cat1Sous3facile, question2Cat1Sous3facile, question3Cat1Sous3facile], totalPointsGagne: jauge, diff: [.facile], selectedQuizz: false)
let quizCat1Sous4 = Quiz(nom: "Nutrition", question: [question1Cat1Sous2facile, question2Cat1Sous2facile, question3Cat1Sous2facile], totalPointsGagne: jauge, diff: [.facile], selectedQuizz: false)

class ChoixQuiz {
    var quiz : Quiz
    var question : Questions
    
    
    init(quiz: Quiz, question: Questions ) {
        self.quiz = quiz
        self.question = question
    }
    
}

struct Jaugeprog {
    var ptsmax : Int
    var ptsrestants : Int
    var pts : Int
}



class Jauge {
    var ptsmax : Int
    var ptsrestants : Int
    var pts : Int
//    var jauge : CGFloat
    
    init(ptsmax: Int, ptsrestants: Int, pts: Int /*jauge: CGFloat*/) {
        self.ptsmax = ptsmax
        self.ptsrestants = ptsrestants
        self.pts = pts
//        self.jauge = CGFloat(pts)
    }
}

var jauge = Jaugeprog (ptsmax: 200, ptsrestants: 200, pts: 0)

struct Reponse: Identifiable {
    var id = UUID()
    var reponse: String
    var bonneReponse : Bool
    var selected = false
}

struct Questions{
    var enonce : String
    var reponses : [Reponse]
    var LaBonneReponse : String
    var score : Int
    var nbPtsQuestion : Int
    var numQuestion: Int
    
}


      

struct Bons {
    var datedebut : Int
    var datefin : Int
    var nompartenaire : String
    var reduction : Int
    var bonvalide : Bool
    var codebarre : String
    
    
}
//    Struct page 3

struct LeconDuJour {
    var lecon : String
    var leconEnonce : String
}


// QUESTION 1: CAREGORIE 1 SOUS-CATEGORIE 1
var question1Cat1Sous1facile = Questions(enonce: "Quel type de végétarisme interdit la consommation de produits d’origine animale, y compris les œufs et les produits laitiers ?", reponses: [vege, pesco, ovo, lacto], LaBonneReponse: "Végétalisme", score: 0, nbPtsQuestion: 10, numQuestion: 1)

    //REPONSE QUESTION 1
    let vege = Reponse(reponse: "Végétalisme", bonneReponse: true)
    let pesco = Reponse(reponse: "Pesco-végétarisme", bonneReponse: false)
    let ovo = Reponse(reponse: "Ovo-végétarisme", bonneReponse: false)
    let lacto = Reponse(reponse: "Lacto-végétarisme", bonneReponse: false)


// QUESTION 2
var question2Cat1Sous1facile = Questions(enonce: "Quel type de végétarisme autorise la consommation de poisson, des crustacés, et des sous-produits d’origine animale, comme les œufs, le lait ou le fromage ?", reponses: [vege2, pesco2, ovo2, lacto2], LaBonneReponse: "Pesco-végétarisme", score: 0, nbPtsQuestion: 10, numQuestion: 2)

    //REPONSE QUESTION 2
    let vege2 = Reponse(reponse: "Végétalisme", bonneReponse: false)
    let pesco2 = Reponse(reponse: "Pesco-végétarisme", bonneReponse: true)
    let ovo2 = Reponse(reponse: "Ovo-végétarisme", bonneReponse: false)
    let lacto2 = Reponse(reponse: "Lacto-végétarisme", bonneReponse: false)

// QUESTION 3
var question3Cat1Sous1facile = Questions(enonce: "Quel type de végétarisme interdit la consommation de viande, mais autorise la consommation d’œufs et de produits d’origine végétale ?", reponses: [vege3, pesco3, ovo3, lacto3], LaBonneReponse: "Ovo-végétarisme", score: 0, nbPtsQuestion: 10, numQuestion: 3)

    //REPONSE QUESTION 3
    let vege3 = Reponse(reponse: "Végétalisme", bonneReponse: false)
    let pesco3 = Reponse(reponse: "Pesco-végétarisme", bonneReponse: false)
    let ovo3 = Reponse(reponse: "Ovo-végétarisme", bonneReponse: true)
    let lacto3 = Reponse(reponse: "Lacto-végétarisme", bonneReponse: false)

// QUESTION 4
var question1Cat1Sous2facile = Questions(enonce: "Quel est le principal nutriment dont les végétariens doivent s'assurer d'avoir suffisamment dans leur alimentation ?", reponses: [vitam,cal,fer,zinc], LaBonneReponse: "La vitamine B12", score: 0, nbPtsQuestion: 10, numQuestion: 4 )

    //REPONSE QUESTION 4
    let vitam = Reponse(reponse: "La vitamine B12", bonneReponse: true)
    let cal = Reponse(reponse: "Le calcium", bonneReponse: false)
    let fer = Reponse(reponse: "Le fer", bonneReponse: false)
    let zinc = Reponse(reponse: "Le zinc", bonneReponse: false)

// QUESTION 5
var question2Cat1Sous2facile = Questions(enonce: "Quels sont les aliments végétaux les plus riches en protéines ?", reponses: [fruitSec,cereales,legumeV,legumineuse], LaBonneReponse: "Les légumineuses", score: 0, nbPtsQuestion: 10, numQuestion: 6 )

    //REPONSE QUESTION 5
    let fruitSec = Reponse(reponse: "Les fruits secs", bonneReponse: false)
    let cereales = Reponse(reponse: "Les céréales", bonneReponse: false)
    let legumeV = Reponse(reponse: "Les légumes verts", bonneReponse: false)
    let legumineuse = Reponse(reponse: "Les légumineuses", bonneReponse: true)

// QUESTION 6
var question3Cat1Sous2facile = Questions(enonce: "Les végétariens peuvent-ils obtenir suffisamment de fer dans leur alimentation ?", reponses: [vege6, ovo6], LaBonneReponse: "Oui", score: 0, nbPtsQuestion: 10, numQuestion: 4)


    //REPONSE QUESTION 4
    let vege6 = Reponse(reponse: "Non", bonneReponse: false)
    let ovo6 = Reponse(reponse: "Oui", bonneReponse: true)

// QUESTION 7
var question1Cat1Sous3facile = Questions(enonce: "Quel est le nom du premier livre publié en français qui défend le végétarisme ?", reponses: [apoge,vie, regime, regime2 ], LaBonneReponse: "La Vie sans viande", score: 0, nbPtsQuestion: 10, numQuestion: 7 )
        

    //REPONSE QUESTION 7
    let apoge = Reponse(reponse: "L'Apologie des végétaux", bonneReponse: false)
    let vie = Reponse(reponse: "La Vie sans viande", bonneReponse: true)
    let regime = Reponse(reponse: "Le Végétalisme", bonneReponse: false)
    let regime2 = Reponse(reponse: " Le Régime végétal", bonneReponse: false)

//QUESTION 8
var question2Cat1Sous3facile = Questions(enonce: "Quel philosophe grec antique est souvent cité comme l’un des premiers végétariens connus de l’histoire ? ", reponses: [vege8, pesco8, ovo8, lacto8], LaBonneReponse: "Pythagore", score: 0, nbPtsQuestion: 10, numQuestion:10 )


    //REPONSE QUESTION 8
    let vege8 = Reponse(reponse: "Aristote", bonneReponse: false)
    let pesco8 = Reponse(reponse: "Socrate", bonneReponse: false)
    let ovo8 = Reponse(reponse: "Platon", bonneReponse: false)
    let lacto8 = Reponse(reponse: "Pythagore", bonneReponse: true)

//QUESTION 9
var question3Cat1Sous3facile = Questions(enonce: "Quelle civilisation antique était réputée pour son végétarisme ?", reponses: [vege9,pesco9,ovo9,lacto9], LaBonneReponse: "L'Inde", score: 0, nbPtsQuestion: 10, numQuestion: 9 )

    //REPONSE QUESTION 9
    let vege9 = Reponse(reponse: "L'Inde", bonneReponse: true)
    let pesco9 = Reponse(reponse: "La Grèce", bonneReponse: false)
    let ovo9 = Reponse(reponse: "L'Égypte", bonneReponse: false)
    let lacto9 = Reponse(reponse: "La Chine", bonneReponse: false)

//QUESTION 10
var question1Cat1Sous4facile = Questions(enonce: "Quel célèbre écrivain français du XIXe siècle était végétarien et a écrit un essai intitulé 'De la viande et des os' ?", reponses: [vege10, pesco10, ovo10, lacto10], LaBonneReponse: "Alphonse de Lamartine", score: 0, nbPtsQuestion: 10, numQuestion:10 )


    //REPONSE QUESTION 10
    let vege10 = Reponse(reponse: "Victor Hugo", bonneReponse: false)
    let pesco10 = Reponse(reponse: "Gustave Flaubert", bonneReponse: false)
    let ovo10 = Reponse(reponse: "Alphonse de Lamartine", bonneReponse: true)
    let lacto10 = Reponse(reponse: "Émile Zola", bonneReponse: false)

//QUESTION 11
var question2Cat1Sous4facile = Questions(enonce: "Quelle est l’origine du terme \"végétarisme\" ?"
                                        , reponses: [vege11, pesco11, ovo11, lacto11], LaBonneReponse: "grec \"vegetas\"", score: 0, nbPtsQuestion: 10, numQuestion:11 )


    //REPONSE QUESTION 11
    let vege11 = Reponse(reponse: "Mot latin \"vegetus\"", bonneReponse: false)
    let pesco11 = Reponse(reponse: "Mot grec \"vegetas\"", bonneReponse: true)
    let ovo11 = Reponse(reponse: "Mot français \"végétalisme\"", bonneReponse: false)
    let lacto11 = Reponse(reponse: "Inventer par Pythagore", bonneReponse: false)

//QUESTION 12
var question3Cat1Sous4facile = Questions(enonce: "Quelle culture culinaire est réputée pour sa richesse et sa diversité en plats végétariens ?", reponses: [vege12,pesco12,ovo12,lacto12], LaBonneReponse: "La cuisine indienne", score: 0, nbPtsQuestion: 10, numQuestion:12 )


    //REPONSE QUESTION 12
    let vege12 = Reponse(reponse: "La cuisine indienne", bonneReponse: true)
    let pesco12 = Reponse(reponse: "La cuisine mexicaine", bonneReponse: false)
    let ovo12 = Reponse(reponse: " La cuisine libanaise", bonneReponse: false)
    let lacto12 = Reponse(reponse: "La cuisine japonaise", bonneReponse: false)
        
 
//struct RetourAuQuiz {
//    var retour : Quiz
//}
//struct Recent{
//    var recent : Quiz
//}



//let type = Categories (nomCat: "Les Types de Végétarismes", imageCat: "nuagev", nomSousCat: ["Définitions", "Histoire", "Culture", "Nutrition"], boiteQuiz: [Quiz(question: [Questions(enonce:"Quel type de végétarisme interdit la consommation de produits d’origine animale, y compris les œufs et les produits laitiers ?","Quel type de végétarisme autorise la consommation de poisson, des crustacés, et des sous-produits d’origine animale, comme les œufs, le lait ou le fromage ?","Quel type de végétarisme interdit la consommation de viande, mais autorise la consommation d’œufs et de produits d’origine végétale ?","Quel est le principal nutriment dont les végétariens doivent s'assurer d'avoir suffisamment dans leur alimentation ?","Quels sont les aliments végétaux les plus riches en protéines ?","Les végétariens peuvent-ils obtenir suffisamment de fer dans leur alimentation ?","Quel est le nom du premier livre publié en français qui défend le végétarisme ?","Quel philosophe grec antique est souvent cité comme l’un des premiers végétariens connus de l’histoire ? ","Quelle civilisation antique était réputée pour son végétarisme ?","Quel célèbre écrivain français du XIXe siècle était végétarien et a écrit un essai intitulé 'De la viande et des os' ?","Quel type de végétarien ne consomme ni viande, ni poisson, mais accepte les œufs et les produits laitiers ?","Quelle culture culinaire est réputée pour sa richesse et sa diversité en plats végétariens ?",  reponses: "Pesco-végétarisme", "Ovo-végétarisme","Lacto-végétarisme","Végétalisme", "Pesco-végétarisme","Ovo-végétarisme","Lacto-végétarisme","Végétalisme","Pesco-végétarisme","Ovo-végétarisme","Lacto-végétarisme","Lacto-végétarisme","La vitamine B12","Le calcium","Le fer","Le zinc","Les fruits secs","Les céréales","Les légumes verts","Les légumineuses","Oui","Non","L'Apologie des végétaux","La Vie sans viande", "Le Végétalisme"," Le Régime végétal","Aristote","Socrate","Platon","Pythagore"," L'Inde","La Grèce", " L'Égypte","La Chine",
//"Victor Hugo","Gustave Flaubert","Alphonse de Lamartine", "Émile Zola",
//"Le végétalien","L'ovo-lacto-végétarien","Le pescetarien","Le vegan",
//"La cuisine indienne","La cuisine mexicaine", "La cuisine libanaise","La cuisine japonaise",
//[Reponse], LaBonneReponse:"Végétalisme","Pesco-végétarisme","Ovo-végétarisme","La vitamine B12","Les légumineuses","Oui","La Vie sans viande","Pythagore","L'Inde","Alphonse de Lamartine","L'ovo-lacto-végétarien","La cuisine indienne", score: 0, nbPtsQuestion: 10, numQuestion:10 ) , score: 0, nbPtsQuestion: 0...9, numQuestion: 0...12)], totalPointsGagne: Jaugeprog(ptsmax:120 , ptsrestants: <#T##Int#>, pts: <#T##Int#>), diff: [Diff(rawValue: <#T##String#>)])])
/*
 let aliment = Categories (nomCat: "Les aliments", imageCat: "legumes", nomSousCat: ["Les proteines", "Fruits et Légumes", "Lait", "oeufs"], boiteQuiz: [Quiz])
 
 let defis = Categories(nomCat: "Les défis", imageCat: "lesdefis", nomSousCat: ["Les préssions", "La santé" , "L'approvisionnement", "La préparation" ], boiteQuiz: [Quiz])
 
 let bienfaits = Categories(nomCat: "Les bienfaits", imageCat: "emma", nomSousCat: ["L'environnement", "La Santé", "L'Ethique", "Produits locaux"], boiteQuiz: [Quiz])
 */
