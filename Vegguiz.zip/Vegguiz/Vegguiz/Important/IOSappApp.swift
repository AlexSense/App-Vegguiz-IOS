//
//  IOSappApp.swift
//  IOSapp
//
//  Created by Apprenant97 on 28/01/2024.
//

import SwiftUI


struct IOSappApp: App {
    var body: some Scene {
        WindowGroup {
            
        }
    }
}

