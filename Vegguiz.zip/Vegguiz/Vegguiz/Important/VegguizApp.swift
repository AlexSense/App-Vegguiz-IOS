//
//  VegguizApp.swift
//  Vegguiz
//
//  Created by Apprenant97 on 07/02/2024.
//

import SwiftUI

@main
struct VegguizApp: App {
    var body: some Scene {
        WindowGroup {
           PageProfil()
        }
    }
}
