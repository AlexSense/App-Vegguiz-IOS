//
//  TabView.swift
//  IOS
//
//  Created by Apprenant97 on 30/01/2024.
//

import SwiftUI

struct LaTabView: View {
    
    @EnvironmentObject var user: User
    
    
    var body: some View {
        
        
            TabView {
                PageProfil()
                    .tabItem { Label("Profil", systemImage: "leaf")
                        }
                    
                
                
                PageCat()
                        .tabItem { Label("Quiz", systemImage: "graduationcap")
                            
                   
                        }
                
                BonsView()
                    .tabItem { Label("Bons d'achat", systemImage: "giftcard")
                                
                }
            }
        }
    }


#Preview {
    LaTabView()
        .environmentObject(User(name: "Thomas", email: "toto@gmail.com", motDePasse: "666", imageprofil: "salad", progression: Jauge(ptsmax: 200, ptsrestants: 200, pts: 60), selectedAnswer: Reponse(reponse: "", bonneReponse: false)))
}
