//
//  ProgressionUser.swift
//  IOS
//
//  Created by Apprenant97 on 06/02/2024.
//

import SwiftUI

struct ProgressionUser: View {
    @EnvironmentObject var user: User
    
    var body: some View {

            VStack{
                HStack(alignment: .center) {
                    
                    Text("\(user.progression.pts) pts")
                        .fontWeight(.semibold)
                        .foregroundStyle(.white)
                    
                    
                    VStack {
                        Gauge(value: Float(user.progression.pts), in: 0...200, label: {
                            Text("")
                        })
                        .padding(.horizontal)
                        .tint(Color.yellow)
                        .background(RoundedRectangle(cornerRadius: 25.0)
                            .fill(.gray).opacity(0.7)
                            .frame(height: 16).padding(.horizontal).padding(.top, 14))
                        
                        Text("points restants \(user.calculPointRestant())")
                            .foregroundColor(Color.white)
                        
                        
                    }
                    
                    
                    VStack{
                        
                        Image(user.imageprofil)
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 50, height: 50)
                            .clipShape(Circle())
                        
                        
                        Text(user.name)
                            .fontWeight(.semibold)
                            .foregroundStyle(.white)
                    }
                    
                }
                .padding(.horizontal)
            }
        }
    }

#Preview {
    ProgressionUser()
        .environmentObject(User(name: "Thomas", email: "thomas@gmail.com", motDePasse: "666", imageprofil: "salad", progression: Jauge(ptsmax: 200, ptsrestants: 200, pts: 70), selectedAnswer: Reponse(reponse: "", bonneReponse: false)))
        .padding()
        .background(Color.green)
}
