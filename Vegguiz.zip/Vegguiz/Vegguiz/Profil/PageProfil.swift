//
//  PageProfil.swift
//  IOS
//
//  Created by Apprenant97 on 28/01/2024.
//

import SwiftUI

struct PageProfil: View {
    
    @EnvironmentObject var user: User
    
    @State private var afficher2 : Bool = false
    @State private var afficher3 : Bool = false
    
    var body: some View {
        
        NavigationStack {
            ZStack{
                
                LinearGradient(colors: [Color("vertp").opacity(0.9), Color("bleuv").opacity(0.79)], startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea( edges: .top)
                
                
                   
                    
                    
                  
                    
                    
                    ScrollView{
                        HStack{
                            
                            VStack(alignment: .leading) {
                                
                                
                                
                                
                                
                                Text("Bonjour \(user.name)")
                                    .font(.largeTitle)
                                    .fontWeight(.semibold)
                                    .foregroundColor(.white)
                                    .padding(.vertical)
                                    .padding(.leading)
                                
                                
                                
                                
                                
                                
                                
                                
                                Text("Ma Progression")
                                    .font(.title)
                                    .foregroundStyle(.white)
                                    .padding(.leading)
                             
                                NavigationLink(destination: PageParametres()){
                                    ZStack{
                                        
                                        RoundedRectangle(cornerRadius: 20)
                                            .fill(Color("bleuv"))
                                            .opacity(1)
                                            .frame(height: 220)
                                            .shadow(color: .black ,radius: 1)
                                        
                                            
                                        
                                        VStack(alignment: .leading){
                                            HStack(alignment: .center, spacing: 60){
                                                VStack{
                                                    ZStack{
                                                       
                                                        Gauge(value: Float(user.progression.pts), in: 0...200, label: {
                                                        })
                                                        .scaleEffect(1.5)
                                                        .gaugeStyle(.accessoryCircular)
                                                        .tint(Color.yellow)
                                                        .shadow(color: .black ,radius: 1)
                                                        .padding(.top)
                                                    }
                                                    Text("points restants \(user.calculPointRestant())")
                                                        .fontWeight(.semibold)
                                                        .foregroundColor(Color.white)
                                                        .padding(.top)
                                                    
                                                }
                                                
                                                VStack{
                                                    Image(user.imageprofil)
                                                        .resizable()
                                                        .aspectRatio(contentMode: .fill)
                                                        .frame(width: 60, height: 60)
                                                        .clipShape(Circle())
                                                        .scaleEffect(1.5)
                                                    
                                                    
                                                    
                                                    
                                                    Text(user.name)
                                                        .fontWeight(.semibold)
                                                        .foregroundStyle(.white)
                                                        .padding(.top)
                                                }.padding(.top)
                                                
                                                
                                            }
                                            RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                                                .fill(.white)
                                                .frame(width: 320, height: 4, alignment: .center)
                                                
                                            Text("\(user.progression.pts) pts")
                                                .fontWeight(.semibold)
                                                .foregroundStyle(.white)
                                            Text("Sans faute: 1")
                                                .fontWeight(.semibold)
                                                .foregroundStyle(.white)
                                            Text("Record de bonne réponses: 5")
                                                .fontWeight(.semibold)
                                                .foregroundStyle(.white)
                                        }
                                        
                                    }.padding(10)
                                        
                                }
                            }
                            
                        }
                        
                        
                        HStack(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, spacing: 2){
                            
                            ZStack{
                                
                                RoundedRectangle(cornerRadius: 20)
                                
                                    .foregroundColor(Color("orangeo"))
                                    .frame(width: 178,height: 230)
                                    .shadow(color: .black ,radius: 1)
                                
                                VStack{
                                    Spacer()
                                    Text("Continuer le Quiz")
                                        .font(.title3)
                                        .fontWeight(.bold)
                                        .padding(.bottom, 5)
                                        .multilineTextAlignment(.center)
                                        .lineLimit(nil)
                                        .foregroundStyle(.white)
                                    
                                    
                                    Spacer()
                                    
                                    Text("Les aliments:")
                                        .fontWeight(.semibold)
                                        .foregroundStyle(.white)
                                        .padding(.bottom,5)
                                    
                                    
                                    Text("Les fruits et légumes")
                                        .fontWeight(.semibold)
                                        .foregroundStyle(.white)
                                    
                                    Spacer()
                                    
                                    Text("1/3")
                                        .font(.title2)
                                        .fontWeight(.semibold)
                                        .foregroundColor(Color("rougef"))
                                    
                                    Spacer()
                                }
                            }
                            ZStack{
                                
                                RoundedRectangle(cornerRadius: 20.0)
                                    .foregroundColor(Color("vertp"))
                                    .frame(width: 178,height: 230)
                                    .shadow(color: .black ,radius: 1)
                                
                                VStack{
                                    
                                    Spacer()
                                    
                                    Text("Récent")
                                        .font(.title2)
                                        .fontWeight(.bold)
                                        .multilineTextAlignment(.center)
                                        .foregroundStyle(.white)
                                        .padding(.bottom)
                                    
                                    Text("Quiz:")
                                        .font(.title2)
                                        .fontWeight(.semibold)
                                    
                                    
                                        .foregroundColor(Color("rougef"))
                                        .multilineTextAlignment(.center)
                                    
                                    
                                    
                                    Text("Les différents types de végétarisme")
                                        .fontWeight(.semibold)
                                        .multilineTextAlignment(.center)
                                        .foregroundStyle(.white)
                                        .padding(.horizontal)
                                    Spacer()
                                    
                                    Text("66% de réusite")
                                        .font(.title2)
                                    
                                        .fontWeight(.semibold)
                                        .foregroundColor(Color("rougef"))
                                        .multilineTextAlignment(.center)
                                        .foregroundStyle(.white)
                                    Spacer()
                                }
                            }
                        }.padding(.leading, 6)
                        
                        HStack{
                            Button(action: {
                                afficher2.toggle()
                                
                                
                                
                            },
                                   label: {
                                Text("Anecdote du Jour")
                                    .font(.title)
                                    .padding()
                                    .foregroundStyle(.white)
                                
//                                Condition pour afficher anecdote
                                if afficher2 == true{
                                    Image(systemName: "arrow.down.circle.fill")
                                        .foregroundColor(.pink)
                                        .font(.largeTitle)
                                        .background(Color.white)
                                        .clipShape(Circle())
                               
                                }
                                else {
                                    Image(systemName: "arrow.right.circle.fill")
                                        .foregroundColor(Color.pink)
                                        .background(Color.white)
                                        .clipShape(Circle())
                                        .foregroundColor(.pink)
                                        .font(.largeTitle)
                                }
                                Spacer()
                            })
                        }
                        if afficher2 {
                            
                  
                            
                            VStack{
                                
                                RoundedRectangle(cornerRadius: 20)
                                    .padding(10)
                                    .frame(width: 360,height: 1120)
                                    .shadow(color: .black ,radius: 1)
                                    .foregroundColor(Color("orangeo"))
                                    
                                    .overlay {
                                        Text("""
                                           Humour:
                                           
                                           Un couple se rend chez des amis pour dîner. En arrivant, ils sont accueillis par le maître de maison, qui leur dit :
                                           
                                           Bonsoir, je suis ravi de vous voir ! Vous allez vous régaler, j’ai préparé un rôti de bœuf avec des pommes de terre et des haricots verts. C’est un plat traditionnel de ma région, vous allez adorer !
                                           
                                           Euh… merci, mais nous sommes végétariens, répond le couple gêné.
                                           
                                           Ah, vous êtes végétariens ? Pas de problème, j’ai pensé à tout ! J’ai aussi fait une salade de fruits avec de la crème chantilly. C’est un dessert délicieux, vous allez adorer !
                                           
                                           Euh… merci, mais nous sommes végétaliens, rectifie le couple encore plus gêné.
                                           Ah, vous êtes végétaliens ? Pas de problème, j’ai pensé à tout ! J’ai aussi acheté du vin rouge avec du fromage. C’est un apéritif savoureux, vous allez adorer !
                                           
                                           Euh… merci, mais nous sommes vegans, insiste le couple désespéré.
                                           Ah, vous êtes vegans ? Pas de problème, j’ai pensé à tout ! J’ai aussi cueilli des fleurs avec de l’eau. C’est une décoration magnifique, vous allez adorer !
                                           """)
                                        .padding(30)
                                    }
                                
                                
                                    .font(.title3)
                                    .multilineTextAlignment(.leading)
                                    .padding()
                            }
                            .foregroundStyle(.white)
                        
                        }
                        
                        
                        
                        
                        
                        
                        VStack{
                            Button(action: {
                                afficher3.toggle()
                                
                                
                                
                            },
                                   label: {
                                HStack{
                                    Text("Recette du Jour")
                                        .font(.title)
                                        .padding(.leading)
                                        .foregroundStyle(.white)
                                    if afficher3 == true{
                                        Image(systemName: "arrow.down.circle.fill")
                                            .foregroundColor(.pink)
                                            .font(.largeTitle)
                                            .background(Color.white)
                                            .clipShape(Circle())
                                        
                                    }
                                    
                                    else {
                                        Image(systemName: "arrow.right.circle.fill")
                                            .foregroundColor(.pink)
                                            .font(.largeTitle)
                                            .background(Color.white)
                                            .clipShape(Circle())
                                        
                                    }
                                }.padding(.top)
                                Spacer()
                            })
                            
                            if afficher3{
                                
                                ZStack{
                                    VStack{
                                        RoundedRectangle(cornerRadius: 20)
                                            .frame(height: 1525)
                                            .foregroundColor(Color("orangeo"))
                                            .shadow(color: .black ,radius: 1)
                                            .overlay {
                                                
                                                
                                                VStack{
                                                    Image("saladefeta")
                                                    
                                                    
                                                        .resizable()
                                                        .scaledToFill()
                                                        .clipShape(RoundedRectangle(cornerRadius: 15))
                                                        .frame(width: 300, height: 450, alignment: .center)
                                                    
                                                    
                                                    Text("""
              Salade de quinoa aux légumes croquants et à la feta
              
              Ingrédients :
              
              200 g de quinoa
              1 concombre
              2 tomates
              1 poivron rouge
              100 g de feta
              4 cuillères à soupe d’huile d’olive
              2 cuillères à soupe de vinaigre balsamique
              Sel, poivre, herbes de Provence
              
              
              Préparation :
              
              Rincez le quinoa sous l’eau froide, puis faites-le cuire dans une casserole d’eau bouillante salée pendant 15 minutes. Égouttez et laissez refroidir.
              
              Lavez et coupez le concombre, les tomates et le poivron en petits dés. Émiettez la feta.
              
              Dans un saladier, mélangez le quinoa, les légumes et la feta. Assaisonnez avec l’huile d’olive, le vinaigre balsamique, le sel, le poivre et les herbes de Provence. Réservez au frais jusqu’au moment de servir.
                                           
              Voilà, votre salade de quinoa est prête ! Vous pouvez la déguster en entrée ou en plat principal, selon votre appétit. Bon appétit !
              """
                                                    )
                                                    .font(.title3)
                                                    .multilineTextAlignment(.leading)
                                                    .padding()
                                                }
                                            }
                                    }
                                    .foregroundStyle(.white)
                                    .padding(30)
                                }
                                
                            }
                            
                        }
                    }
                }
            }
            
        }
        
    }

#Preview {
    PageProfil()
        .environmentObject(User(name: "Thomas", email: "thomas@gmail.com", motDePasse: "666", imageprofil: "salad", progression: Jauge(ptsmax: 200, ptsrestants: 200, pts: 60), selectedAnswer: Reponse(reponse: "", bonneReponse: false)))
}
