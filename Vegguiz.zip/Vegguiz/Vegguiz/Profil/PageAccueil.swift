//
//  PageAccueil.swift
//  IOS
//
//  Created by Apprenant97 on 28/01/2024.
//

import SwiftUI

struct PageAccueil: View {
    
  
    @State private var seConnecter = false
    
    @State private var emailField = "Thomas@gmail.com"
    @State private var passwordField = "666"
    
   
    
    @State private var login = false
    
    @EnvironmentObject var user: User
    
    func fonction () {
        if emailField == user.email &&
            passwordField == user.motDePasse {
            login = true
        }
    }
    
    var body: some View {
        NavigationStack{
    ZStack{
//            Rectangle()
//                .foregroundColor(Color("bleuv"))
//                .ignoresSafeArea()
            
        VStack(spacing: 0){
            
                Image("photoMain")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
            
            ZStack{
                Rectangle()
                    .foregroundColor(Color("bleuv"))
                    .ignoresSafeArea()
                    .frame(height: 500)
                    
                VStack{
                    if seConnecter == false{
                        ZStack{
                            
                            RoundedRectangle(cornerRadius: 20)
                                .frame(width: 300, height: 60)
                                .padding(.top, 25)
                            
                            HStack{
                                Image(systemName : "applelogo")
                                    .foregroundStyle(.white)
                                    .font(.title)
                                   
                                    .padding(.top,20)
                                
                                
                                Text("Continuer avec apple")
                                    .foregroundStyle(.white)
                                    .padding(.top, 25)
                                
                            }
                        }
                    } else{
                        ZStack{
                            
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundColor(.white)
                                .frame(width: 350, height: 60)
                                .padding(.top, 25)
                            
                            HStack{
                               
                                
                                TextField("Email:", text: $emailField)
                                    .padding(.leading, 30)
                                    .foregroundStyle(.primary)
                                    .padding(.top, 25)
                                    .font(.title2)
                                
                            }
                        }
                    }
                    
                    if seConnecter == false{
                        ZStack{
                            
                            RoundedRectangle(cornerRadius: 20)
                                .frame(width: 300, height: 60)
                                .foregroundStyle(Color.blue)
                                .padding(.top, 10)
                            
                            HStack{
                                Image("logogoogle")
                                    .resizable()
                                    .frame(width: 45, height: 45)
                                    .padding(.top, 10)
                      
                                Text("Continuer avec google")
                                    .foregroundStyle(.white)
                                    .padding(.top, 10)
                                
                            }
                        }
                    }
                    else {
                        ZStack{
                            
                            RoundedRectangle(cornerRadius: 20)
                                .frame(width: 350, height: 60)
                                .foregroundStyle(Color.white)
                                .padding(.top, 10)
                            
                            HStack{
                               
                                
                                TextField("Mot de passe:", text: $passwordField)
                                    .padding(.top, 5)
                                    .padding(.leading, 30)
                                    .foregroundStyle(.primary)
                                    .font(.title2)
                               
                                
                            }
                            }
                    }
                    Button(action: {
                        if seConnecter != true{
                            seConnecter = true}
                        
                        fonction()
                        
                    
                    }, label: {
                        
                        if seConnecter == false{
                            ZStack{
                                
                                RoundedRectangle(cornerRadius: 20)
                                    .frame(width: 175, height: 60)
                                    .foregroundStyle(Color.white)
                                    .padding(.top, 10)
                                
                                HStack{
                                    
                                    Text("Se connecter")
                                        .foregroundStyle(.black)
                                        .padding(.top, 10)
                                    
                                }
                            }
                        }
                        else {
                            if login {
                                
                                NavigationLink(destination: PageProfil()){
                            ZStack{
                                
                                        RoundedRectangle(cornerRadius: 20)
                                            .frame(width: 175, height: 60)
                                            .foregroundStyle(Color.red).opacity(0.8)
                                            .padding(.top, 10)
                                        
                                        HStack{
                                            
                                            Text("Confirmer")
                                                .fontWeight(.semibold)
                                                .foregroundStyle(.white)
                                                .padding(.top, 10)
                                            
                                        }
                                    }
                                      
                                }
                            }
                        }
                            
                    })
                    
                Text("Vous n'avez pas de compte?")
                    .foregroundColor(Color.white)
                    .padding(.top)
                
                NavigationLink(destination: RegistrationView()){
                        Text("Créer un compte")
                            .fontWeight(.bold)
                            .foregroundColor(Color.white)
                    }
                Spacer()
                    
                    }
                
                }
            }
          
            Rectangle()
                .fill(.linearGradient(colors: [Color("bleuv"), Color.clear], startPoint: .bottom, endPoint: .top))
                .frame(height: 50)
                .padding(.top, 40)
            
        HStack{
            
            Spacer()
            NavigationLink(destination: PageProfil()){
                Text("Passer")
                    .fontWeight(.bold)
                    .foregroundColor(Color.white)
                    .padding(.trailing)
                    .padding(.bottom, 720)
            }
        }
        
        VStack{
            Text("Végguiz")
                .font(.title)
                .fontWeight(.heavy)
                .foregroundColor(Color.white)
                .font(.system(size: 100))
                .shadow(radius: 1, x:3, y:3)
                
            Text("L'appli qui t'instruit et qui t'aide à te nourrir")
                .font(.title)
                .fontWeight(.medium)
                .foregroundColor(Color.white)
                .multilineTextAlignment(.center)
                .shadow(radius: 10)
                .padding(.horizontal)
                
        }
        .padding(.bottom, 120.0)
            }
           
        }
       
    }
}
        

#Preview {
    PageAccueil()
        .environmentObject(User(name: "Thomas", email: "Thomas@gmail.com", motDePasse: "666", imageprofil: "salad", progression: Jauge(ptsmax: 200, ptsrestants: 200, pts: 60), selectedAnswer: Reponse(reponse: "", bonneReponse: false)))
}
