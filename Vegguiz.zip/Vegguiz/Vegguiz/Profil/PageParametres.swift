//
//  PageParametres.swift
//  IOS
//
//  Created by Apprenant97 on 28/01/2024.
//

import SwiftUI

struct PageParametres: View {
    
    @State private var userNameFild = ""
    @State private var emailField = ""
    @State private var passwordField = ""
    
    @EnvironmentObject var user: User
    
    var body: some View {
        NavigationStack{
            ZStack{
                LinearGradient( colors:[Color("vertp"), Color("bleuv") ],
                                startPoint:.top,
                                endPoint: .bottom)
                .ignoresSafeArea()
                
                VStack{
                    
                    Image(user.imageprofil)
                        .resizable()
                        .frame(width: 250, height: 250)
                        .aspectRatio(contentMode: .fill)
                        .clipShape(Circle())
                        .frame(width: 250, height: 250)
                    
                    
                    
                    Text("Modifier la photo")
                        .foregroundColor(Color.white)
                        .padding(.bottom, 30)
                    
                    HStack{
                        Text("Changer de nom d’utilsateur:")
                            .fontWeight(.semibold)
                            .padding(.leading, 25)
                            .opacity(/*@START_MENU_TOKEN@*/0.8/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                        Spacer()
                    }
                    
                    ZStack{
                        
                        RoundedRectangle(cornerRadius: 15)
                            .frame(width: 350, height: 60)
                            .foregroundColor(.gray)
                            .opacity(/*@START_MENU_TOKEN@*/0.8/*@END_MENU_TOKEN@*/)
                        
                        HStack {
                            TextField(user.name, text: $user.name)
                                .fontWeight(.semibold)
                                .font(.system(size: 24))
                                .foregroundColor(Color.white)
                                .multilineTextAlignment(.leading)
                                .frame(width: 350)
                                .padding(.leading, 30.0)
                            Spacer()
                        }
                        
                    }
                    ZStack{
                        RoundedRectangle(cornerRadius: 15)
                            .frame(width: 350, height: 60)
                            .foregroundColor(Color.gray)
                            .opacity(/*@START_MENU_TOKEN@*/0.8/*@END_MENU_TOKEN@*/)
                        
                        HStack{
                            Text(user.email)
                                .fontWeight(.semibold)
                                .foregroundColor(Color.white)
                                .multilineTextAlignment(.leading)
                                .frame(width: 380)
                            Spacer()
                        }
                    }
                    HStack{
                        Text("Changer le mot de passe:")
                            .fontWeight(.semibold)
                            .padding(.leading, 25)
                            .opacity(/*@START_MENU_TOKEN@*/0.8/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                        Spacer()
                    }
                    
                    ZStack{
                        RoundedRectangle(cornerRadius: 15)
                            .frame(width: 350, height: 60)
                            .foregroundColor(.gray)
                            .opacity(/*@START_MENU_TOKEN@*/0.8/*@END_MENU_TOKEN@*/)
                        
                        HStack(alignment: .center){
                            SecureField(user.motDePasse, text: $user.motDePasse)
                                .fontWeight(.semibold)
                                .font(.system(size: 24))
                                .foregroundColor(Color.white)
                                .multilineTextAlignment(.leading)
                                .frame(width: 350)
                                .padding(.leading, 30.0)
                            
                            Spacer()
                            
                            
                            
                            
                        }
                    }
                    Text("Vous n'avez pas de compte?")
                        .foregroundColor(Color.white)
                        .padding(.top)
                    
                    NavigationLink(destination: RegistrationView()){
                        Text("Créer un compte")
                            .fontWeight(.bold)
                            .foregroundColor(Color.white)
                        
                        Text("ou")
                        
                            .foregroundColor(Color.white)
                        NavigationLink(destination: PageAccueil()){
                            Text("Connectez-vous")
                                .fontWeight(.bold)
                                .foregroundColor(Color.white)
                        }
                    }
                }
            }
        }
    }
}
#Preview {
    PageParametres()
        .environmentObject(User(name: "Thomas", email: "thomas@gmail.com", motDePasse: "666", imageprofil: "salad", progression: Jauge(ptsmax: 200, ptsrestants: 200, pts: 60), selectedAnswer: Reponse(reponse: "", bonneReponse: false)))
    
}
