//
//  PageAccueil2.swift
//  IOS
//
//  Created by Apprenant97 on 28/01/2024.
//

import SwiftUI

struct RegistrationView: View {
    
    
    @State private var username = ""
    @State private var email = ""
    @State private var password = ""
    
    @State private var confirmedUser = false
    
    func fonction () {
    }
    
    var body: some View {
        NavigationStack{
            ZStack{
                LinearGradient( colors:[Color("vertp"), Color("bleuv") ],
                                startPoint:.top,
                                endPoint: .bottom)
                .ignoresSafeArea()
                
                VStack{
                    
                    HStack{
                        
                        Spacer()
                        NavigationLink(destination:PageProfil()){
                            
                            Text("Passer")
                                .fontWeight(.bold)
                                .foregroundColor(Color.white)
                                .padding(.trailing)
                        }
                    }
                    
                    Image(systemName: "person.crop.circle")
                        .resizable()
                        .frame(width: 250, height: 250)
                        .foregroundColor(.white)
                    
                    Text("Ajouter une photo")
                        .foregroundColor(Color.white)
                        .padding(.bottom, 50)
                    
                    VStack(spacing: 15){
                        ZStack{
                            
                            RoundedRectangle(cornerRadius: 15)
                                .frame(width: 350, height: 60)
                                .foregroundColor(.white)
                            
                            
                            HStack {
                                
                                TextField("Nom:", text: $username)
                                    .fontWeight(.semibold)
                                    .font(.system(size: 20))
                                    .foregroundColor(Color.black)
                                    .multilineTextAlignment(.leading)
                                    .padding(.leading, 30)
                                //                                    .padding(.leading)
                                    .frame(width: 300)
                                
                                Spacer()
                            }
                        }
                        
                        ZStack{
                            
                            RoundedRectangle(cornerRadius: 15)
                                .frame(width: 350, height: 60)
                                .foregroundColor(Color.white)
                            
                            
                            HStack{
                                
                                TextField("Email:", text: $email)
                                    .fontWeight(.semibold)
                                    .font(.system(size: 20))
                                    .foregroundColor(Color.black)
                                    .multilineTextAlignment(.leading)
                                    .padding(.leading, 30)
                                    .frame(width: 300)
                                
                                Spacer()
                            }
                        }
                        
                        ZStack{
                            
                            RoundedRectangle(cornerRadius: 15)
                                .frame(width: 350, height: 60)
                                .foregroundColor(.white)
                            
                            
                            HStack(alignment: .center){
                                
                                TextField("Mot de passe:", text:$password)
                                    .fontWeight(.semibold)
                                    .font(.system(size: 20))
                                    .foregroundColor(Color.black)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: 300)
                                    .padding(.leading, 30.0)
                                
                                Spacer( )
                                
                            }
                        }
                        NavigationLink(destination: PageProfil()){
                            ZStack{
                                
                                RoundedRectangle(cornerRadius: 15)
                                    .frame(width: 250, height: 60)
                                    .foregroundColor(.red)
                                    .opacity(0.8)
                                
                                Text("Continuer")
                                    .fontWeight(.semibold)
                                    .font(.system(size: 20))
                                    .foregroundColor(Color.white)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: 300)
                            }
                        }
                        
                    }
                        Spacer()
                        
                        Text("Vous avez un compte?")
                            .foregroundColor(Color.white)
                        NavigationLink(destination: PageAccueil()){
                            Text("Connectez-vous")
                                .fontWeight(.bold)
                                .foregroundColor(Color.white)
                        }
                        Spacer()
                    }
                  
                
            }
        }
        
    }
        
    }






struct RegistrationView_Previews: PreviewProvider {
    static var previews: some View {
        RegistrationView()
    }
}

