//
//  PageSousCat.swift
//  IOS
//
//  Created by Apprenant97 on 28/01/2024.
//

import SwiftUI

struct PageSousCat: View {
    
    @Binding var selectedCat: Categories
    //selectedCat.boiteQuiz -> boucle
    
    @State private var selectedIndex: Int? = nil
    
    @EnvironmentObject var user: User
    
    var body: some View {
        ZStack{
            LinearGradient(colors: [Color.pink.opacity(0.75), Color.pink.opacity(0.6), Color("vertp").opacity(0.5), Color("vertp").opacity(0.46), Color.yellow.opacity(0.6)], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            
            ZStack{
                VStack{
          
                    ProgressionUser()
                    HStack(alignment: .center) {
                        //
                        //                        Text("points")
                        //                            .foregroundStyle(.black)
                        //
                        //                        RoundedRectangle(cornerRadius: 25.0)
                        //                            .frame(width: 200,height: 20)
                        //
                        //                        VStack{
                        //
                        //                            Image(systemName: "person.circle")
                        //                                .resizable()
                        //                                .frame(width: 50, height: 50)
                        //                            Text("Nom")
                        //                                .foregroundStyle(.black)
                        //
                        //                        }
                    }
                    Spacer()
                    ZStack {
                        RoundedRectangle(cornerSize: CGSize(width: 20, height: 20))
                            .frame(width: 105,height: 55)
                            .foregroundColor(Color("vertp"))
                        
                        RoundedRectangle(cornerSize: CGSize(width: 20, height: 20))
                            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/,height: 50)
                            .foregroundStyle(.white)
                        
                        Text("facile")
                            .foregroundStyle(LinearGradient(colors: [Color("vertp"), Color("bleuv")], startPoint: .top, endPoint: .bottom))
                    }
                    Spacer()
                    HStack{
                        Text("Types de végétarismes :")
                            .font(.title)
                            .fontWeight(.semibold)
                            .padding(.leading, 25)
                            .foregroundStyle(.white)
                        Spacer()
                    }
                    Spacer()
                    
                    ForEach(selectedCat.boiteQuiz){ choixCat in
                        
                        Button {
                            if let index = selectedCat.boiteQuiz.firstIndex(where: { choixSousCat in
                                choixCat.id == choixSousCat.id
                            }) {
                                
                                //ici déballe l'optionnel pour modifier la valeur du bool à l'aide de selectedIndex2
                                if let unwrappedIndex = selectedIndex {
                                    selectedCat.boiteQuiz[unwrappedIndex].selectedQuizz.toggle()
                                }
                                
                                //quand j'appuis ça selectionne un button -> on récup l'index
                                selectedIndex = index
                                
                                //ce code déselectionne les buttons qui ne coresspondent pas à l'index de selectIndex2
                                selectedCat.boiteQuiz[index].selectedQuizz.toggle()
                                
                            }
                            
                            
                        } label: {
                            ZStack{
                                RoundedRectangle(cornerRadius: 15)
                                    .frame(width: 350, height: 70)
                                    .foregroundStyle( choixCat.selectedQuizz ? Color("orangeo") : Color("bleuv"))
                                
                                
                                Text(choixCat.nom)
                                    .font(.title3)
                                    .fontWeight(.semibold)
                                    .foregroundStyle(choixCat.selectedQuizz ? .white : .white)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: 100)
                            }
                        }
                    }
                    
                    
                    NavigationLink {
                     
                        QuizView(quizSelected: $selectedCat.boiteQuiz[selectedIndex ?? 0])
                        //selectedCat.boiteQuiz[selectedIndex]
                        //                        QuizView(quizSelected:  selectedCat.boiteQuiz[selectedIndex ?? 0])
                    } label: {
                        if selectedIndex == nil {
                            ZStack{
                                RoundedRectangle(cornerRadius: 15)
                                    .frame(width: 150, height: 60)
                                    .foregroundColor(Color.gray)
                                    .opacity(0.98)
                                    .disabled(false)
                                    .padding([.top, .bottom], 30)
                                
                                
                                Text("Continuer")
                                    .font(.title2)
                                    .fontWeight(.semibold)
                                    .foregroundColor(Color.white)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: 100)
                                    .padding([.top, .bottom], 30)
                            }
                        }
                        else{
                            ZStack{
                                RoundedRectangle(cornerRadius: 15)
                                    .frame(width: 150, height: 60)
                                    .foregroundColor(Color("rougef"))
                                    .opacity(0.98)
                                    .padding([.top, .bottom], 30)
                                
                                
                                Text("Continuer")
                                    .font(.title2)
                                    .fontWeight(.semibold)
                                    .foregroundColor(Color.white)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: 100)
                                    .padding([.top, .bottom], 30)
                            }
                           
                        }
                    }
                }
            }
           
        }
    }
}

#Preview {
    PageSousCat(selectedCat: .constant(type))
        .environmentObject(User(name: "Thomas", email: "toto@gmail.com", motDePasse: "666", imageprofil: "salad", progression: Jauge(ptsmax: 200, ptsrestants: 200, pts: 70), selectedAnswer: Reponse(reponse: "", bonneReponse: false)))
}
