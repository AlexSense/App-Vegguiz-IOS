//
//  PageCat.swift
//  IOS
//
//  Created by Apprenant97 on 28/01/2024.
//

import SwiftUI

struct PageCat: View {
    
    
    init() {
        // Sets the background color of the Picker
        UISegmentedControl.appearance().backgroundColor = .orange
        UISegmentedControl.appearance().selectedSegmentTintColor = UIColor(Color("rougef"))
        
        UISegmentedControl.appearance().setTitleTextAttributes([.foregroundColor: UIColor.white], for: .selected)
        
    }
    
    var vGridLayout = [ GridItem(.adaptive(minimum: 150, maximum: 230)),GridItem(.adaptive(minimum: 150, maximum: 230))]
    
    @State  var difficulte : String = "Facile"
    
    @State private var allCategories = cat
    
    @EnvironmentObject var user: User
 
    
    var body: some View {
        NavigationStack{
            
            
            ZStack{
                LinearGradient(colors: [Color.yellow.opacity(0.7),Color("vertp").opacity(0.65), Color("vertp").opacity(0.75), Color("bleuv2").opacity(0.35),Color("bleuv2").opacity(0.35)], startPoint: .topLeading , endPoint: .bottomTrailing)
                    .ignoresSafeArea()
                
                VStack {
                    NavigationLink {
                        PageParametres()
                    } label: {
                        ProgressionUser()
                    }

                
                    
                    
                    ZStack {
                        RoundedRectangle(cornerSize: CGSize(width: 20, height: 20))
                            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/,height: 50)
                            .foregroundStyle(.white)
                        Text("Quiz")
                            .foregroundStyle(LinearGradient(colors: [Color("vertp"), Color("bleuv")], startPoint: .top, endPoint: .bottom))
                    }
                    
                        Picker(selection: $difficulte, label: /*@START_MENU_TOKEN@*/Text("Picker")/*@END_MENU_TOKEN@*/){
                            
                            Text("Facile").tag("Facile")
                            Text("Normal").tag("Normal")
                            Text("Difficile").tag("Difficile")
                        }
                        .pickerStyle(.segmented)
                        .padding()
                    
                    HStack{
                        Text("Choix de catégories:")
                            .font(.title)
                            .padding(.leading)
                            .foregroundStyle(.white)
                        Spacer()
                    }
                    ZStack{
                        
                        RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                            .foregroundStyle(Color("bleuv").opacity(0.4))
                            .padding()
                        
                        LazyVGrid(columns: vGridLayout) {
                            ForEach(allCategories) { value in
                                
                                //navLink
                                
                                if let index = allCategories.firstIndex(where: { toto in
                                    value.id == toto.id
                                }) {
                                    
                                    
                                    
                                    NavigationLink(destination: PageSousCat(selectedCat: $allCategories[index])){
                                        VStack{
                                        
                                            
                                            Image(value.imageCat)
                                                .resizable()
                                                .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                                                .frame(width: 135, height: 135)
                                                .cornerRadius(20)
                                                
                                            
                                            
                                            
                                    
                                            Text(value.nomCat)
                                                .foregroundStyle(.white)
                                                .frame(height: 45)
                                            
                                            
                                        }
                                        // fin navLink
                                    }
                                }
                            }
                        }
                        .padding()
                        .padding(.top)
                        
                        
                    }
                    
                    Spacer()
                }
            }
        }
    }
    
}

    

#Preview {
    PageCat()
        .environmentObject(User(name: "Thomas", email: "toto@gmail.com", motDePasse: "666", imageprofil: "salad", progression: Jauge(ptsmax: 200, ptsrestants: 200, pts: 60), selectedAnswer: Reponse(reponse: "", bonneReponse: false)))
}
/*      VStack(spacing: -5){
    HStack(alignment: .center, spacing:-10){
        
        NavigationLink(destination: PageSousCat()){

        VStack{
           
                ZStack{
                    RoundedRectangle(cornerRadius: 20)
                        .frame(width: 200, height: 00)
                    Image("nuagev")
                        .resizable()
                        .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                        .frame(width: 150, height: 150)
                        .cornerRadius(20)
                        .scaledToFill()
                    
                    
                }
                
                
                
                Text("Types de végétarismes")
                    .multilineTextAlignment(.center)
                    .frame(width: 150)
                    .foregroundStyle(.white)
                    .padding(.bottom, 20.0)
                
            }
        }
        
        NavigationLink(destination: PageSousCat()){
            VStack{
                VStack{
                    
                    Image("legumes")
                        .resizable()
                        .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                        .frame(width: 150, height: 150, alignment: .center)
                        .cornerRadius(20)
                        .padding(.trailing, 25)
                    
                    
                    
                    
                }
                Text("Les aliments")
                
                    .foregroundStyle(.white)
                    .padding(.bottom ,40)
                    .padding(.trailing, 25)
                
                
                
                
            }
        }
    }
    HStack(spacing: 15){
        
        NavigationLink(destination: PageSousCat()){
            VStack{
                Image("lesdefis")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 150, height: 150)
                    .cornerRadius(20)
                
                Text("Les défis")
                    .foregroundStyle(.white)
                
            }
        }
        
        NavigationLink(destination: PageSousCat()){
            VStack{
                
                Image("emma")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 150, height: 150)
                    .cornerRadius(20)
                
                Text("Les bienfaits")
                    .foregroundStyle(.white)
            }
        }
    }
} */
