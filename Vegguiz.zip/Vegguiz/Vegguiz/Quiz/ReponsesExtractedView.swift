//
//  ReponsesExtractedView.swift
//  IOS
//
//  Created by Apprenant97 on 02/02/2024.
//

import SwiftUI

struct ReponsesExtractedView: View {
    
    @EnvironmentObject var user: User
    
    @Binding var tableauQuestions: Questions
    @Binding var questionChoisie: Int
    @Binding var indexChoisi: Int?
    
    let question: Reponse
    
    var body: some View {
        
        
        
            VStack{
                
                Button(action: {
                    
                    
                    if let index = tableauQuestions.reponses.firstIndex(where: { toto in
                        question.id == toto.id
                        
                    }) {
                        
                        //ici déballe l'optionnel pour modifier la valeur du bool à l'aide de selectedIndex
                        if let unwrappedIndex = indexChoisi {
                            tableauQuestions.reponses[unwrappedIndex].selected.toggle()
                            
                        }
                        
                        //quand j'appuis ça selectionne un button -> on récup l'index
                        indexChoisi = index
                        user.selectedAnswer = tableauQuestions.reponses[index]
                        
                       
                        
                        //ce code déselectionne les buttons qui ne coresspondent pas à l'index de selectIndex
                        tableauQuestions.reponses[index].selected.toggle()
                        //                            print(question1.reponses)
                        
                        
                        
                        
                        
                        print("pressed")
                        if question.bonneReponse && questionChoisie == 2{
                            //                                                    question1.bonnereponse = true
                            tableauQuestions.score = 30
                            print(tableauQuestions.score)
                        }
                        else {
                            //                                                    question1.bonnereponse = false
                            tableauQuestions.score = 0
                            print(tableauQuestions.score)
                        }
                    }
                    
                }, label: {
                    ZStack{
                        
  
                            
                            RoundedRectangle(cornerRadius: 20)
                            .fill(question.selected ? Color("orangeo") : .white)
                                .frame(width: 300,height: 45)
                                .padding(5)
                            Text(question.reponse)
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundStyle(question.selected ? .white : .black)
 
                    }
                })
                
            }
            .onAppear {
                if let index = tableauQuestions.reponses.firstIndex(where: { toto in
                    question.id == toto.id
                    
                }) {
                    if tableauQuestions.reponses[index].bonneReponse {
                        user.bonneReponse = tableauQuestions.reponses[index]
                    }
                }
            }
        
    }
}
