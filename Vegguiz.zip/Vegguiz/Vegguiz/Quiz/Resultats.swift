//
//  Resultats.swift
//  IOS
//
//  Created by Apprenant97 on 28/01/2024.
//

import SwiftUI

struct Resultats: View {
    
    //let Int
    @EnvironmentObject var user: User
    
    var body: some View {
        NavigationStack{
            
          
                ZStack{
                    RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                        .foregroundStyle(Color("bleuv"))
                        .padding()
                    
                    
                    HStack{
                        
                        VStack{
                            
                            Text("Félicitations \(user.name)")
                                .font(.largeTitle)
                                .multilineTextAlignment(.center)
                                .bold()
                                .foregroundColor(Color.yellow)
                                .frame(width: 310)
                                .padding(.vertical,30)
                                .shadow(radius: 1 ,x: 3, y: 5)
                            
                            
                            
                            
                            Text("Tu as répondu correctement à 2/3 des questions")
                                .frame(width: 310)
                                .font(.largeTitle)
                                .foregroundColor(Color.white)
                                .multilineTextAlignment(.center)
                                .padding(.bottom, 30.0)
                            
                            VStack{
                                
                                ZStack{
                                    
                                    
                                    VStack {
                                        Gauge(value: Float(user.progression.pts), in: 0...200, label: {
                                            Text("\(user.progression.pts) pts")
                                                .foregroundStyle(.white)
                                                .padding(0)
                                        })
                                        .padding(.horizontal)
                                        .padding(.bottom)
                                        .tint(Color.yellow)
                                    .background(RoundedRectangle(cornerRadius: 25.0)
                                        .fill(.gray).opacity(0.7)
                                        .frame(height: 20).padding(.horizontal).padding(.top, 14))
                                        
                                            
                                            
                                    }.padding(.horizontal)
                                }
                                
                                
                                Text("Il te reste \(user.calculPointRestant()) points à gagner pour obtenir un coupon (1/4)")
                                    .font(.largeTitle)
                                    .foregroundColor(Color.white)
                                    .multilineTextAlignment(.center)
                                    .lineLimit(3)
                                
                                
                                
                                NavigationLink(destination: PageCat()){
                                   
                                        
                                        Text("Confirmer")
                                            .font(.title2)
                                            .padding()
                                            .foregroundStyle(Color.white)
                                            .background(Color("rougef"))
                                                .clipShape(RoundedRectangle(cornerRadius: 10))
                                                .frame(width: 220, height: 50)
                                        
                                    
                                }.padding(.bottom, 35)
                                    .padding(.top)
                            }
                        }
                        
                    }
                }
            }
        }
    }


#Preview {
    Resultats()
        .environmentObject( User(name: "Thomas", email: "toto@gmail.com", motDePasse: "666", imageprofil: "salad", progression: Jauge(ptsmax: 200, ptsrestants: 200, pts: 60), selectedAnswer: Reponse(reponse: "", bonneReponse: false)))
}
