//
//  Quiz.swift
//  IOS
//
//  Created by Apprenant97 on 28/01/2024.
//

import SwiftUI

struct QuizView: View {
  
    @EnvironmentObject var user: User
    @Binding var quizSelected: Quiz
    
    @State private var quiz = quizCat1Sous1
    @State private var question1 = question1Cat1Sous1facile
    @State private var question2 = question2Cat1Sous1facile
    @State private var question3 = question3Cat1Sous1facile
    
    //lier aux Bindings
    @State private var popUp = false
    @State private var questionEnCours = 0
    @State private var selectedIndex: Int? = nil
//    @Binding var indexFromBack: Int?
    //@State -> Bool? = nil
    
    //1 - @State -> bool
    
    var body: some View {
        //byebye v
        
            
        ZStack {
            VStack(spacing: -10){
                Image(systemName: "arraw.left")
                VStack(spacing: -85){
                    //            HStack{
                    //                Image(systemName: "arrowshape.backward.fill")
                    //            }
                    
                    ZStack{
                        
                        RoundedRectangle(cornerRadius: 25)
                        //                    .frame(width:368, height: 450)
                            .foregroundStyle(Color("vertp"))
                        //                    .padding(20)
                        
                        
                        
                        
                        
                        VStack{
                            
                            HStack{
                                Spacer()
                                
                                ZStack{
                                    RoundedRectangle(cornerRadius: (10))
                                        .frame(width:90, height: 30)
                                        .foregroundStyle(Color("rougef"))
                                    Text("Facile")
                                        .fontWeight(.bold)
                                        .foregroundStyle(.white)
                                    
                                        .padding(.horizontal)
                                    
                                }
                                Spacer()
                                
                                ZStack{
                                    RoundedRectangle(cornerRadius: 10)
                                        .frame(width:90, height: 30)
                                        .foregroundStyle(.white)
                                    
                                    Text("\(questionEnCours+1) / 3")
                                    
                                }
                                
                                Spacer()
                                
                                Image(systemName: "speaker.wave.3.fill")
                                    .padding(.horizontal)
                                
                                Spacer()
                                
                            }.padding(.top, 10)
                            
                            Spacer()
                            
                            Text(quizSelected.question[questionEnCours].enonce)
                                .multilineTextAlignment(.center)
                                .frame(width: 320)
                                .font(.title)
                                .foregroundStyle(.white)
                                .padding(.bottom, 30)
                            Spacer()
                            
                        }
                        
                    }
                    .frame(height: 350)
                    
                    
                    ZStack{
                        
                        
                        RoundedRectangle(cornerRadius: 25)
                        
                            .foregroundColor(Color("bleuv"))
                            .frame(height: 275)
                        //                        .padding()
                        //                        .frame(width: 400, height: 575)
                        
                        VStack{
                            
                            
                            Spacer()
                            
                            VStack{
                                
                                ForEach(quizSelected.question[questionEnCours].reponses) { bonneReponse1Cat1Sous1 in
                                    
                                    ReponsesExtractedView(tableauQuestions: $quizSelected.question[questionEnCours], questionChoisie: $questionEnCours, indexChoisi: $selectedIndex, question: bonneReponse1Cat1Sous1)
                                    
                                }
                                
                            }
                            
                            Spacer()
                            
                            
                            
                            
                        }
                    }
                    .frame(height: 350)
                    //                    .padding()
                    
                    //            .padding()
                }
                
                VStack{
                    
                    Button(action: {
                        //2 - toggle le @State
                        
                        //                            if selectedIndex != nil{
                        //
                        popUp = true
                        //
                        //                                if quizSelected.question.[questionEnCours].laBonneReponse
                        //                            }
                        
                        
                    }, label: {
                        VStack{
                            ZStack{
                                if selectedIndex == nil {
                                    
                                    RoundedRectangle(cornerRadius: 15)
                                        .frame(width: 175,height: 50)
                                        .foregroundStyle(Color.gray)
                                        .disabled(false)
                                    Text("Confirmer")
                                        .font(.title2)
                                        .padding()
                                        .foregroundStyle(Color.white)
                                    
                                    
                                } else {
                                    RoundedRectangle(cornerRadius: 15)
                                        .frame(width: 175,height: 50)
                                        .foregroundStyle(Color("rougef"))
                                    Text("Confirmer")
                                        .font(.title2)
                                        .padding()
                                        .foregroundStyle(Color.white)
                                }
                            }
                            Spacer()
                        }
                        
                        
                    }).padding(.bottom)
                    //                    }
                }
                Spacer()
                }
                .padding()
                .padding(.top)
                
                
                //3 - if toggle true -> popUp
                //                PopUpAnswer()
                if popUp == true {
                    PopUpAnswer(popUp: $popUp, selectedIndex: $selectedIndex, questionEnCours: $questionEnCours)
                    
                    
                }
                
            }
        
            
        }
    }

#Preview {
    QuizView(quizSelected: .constant(quizCat1Sous1))
        .environmentObject( User(name: "Toto", email: "toto@gmail.com", motDePasse: "666", imageprofil: "toto.img", progression: Jauge(ptsmax: 200, ptsrestants: 200, pts: 0), selectedAnswer: Reponse(reponse: "", bonneReponse: false)))
}




//                                if questionEnCours == 0{
//                                quizSelected.question[questionEnCours].enonce
//                                }
//                                else if questionEnCours == 2{
//                                    Text(quiz.question[1].enonce)
//                                        .multilineTextAlignment(.center)
//                                        .frame(width: nil)
//                                        .font(.title)
//                                        .foregroundStyle(.white)
//                                        .padding(.bottom, 30)
//                                    Spacer()
//                                }else if questionEnCours == 3 {
//                                    Text(quiz.question[2].enonce)
//                                        .multilineTextAlignment(.center)
//                                        .frame(width: nil)
//                                        .font(.title)
//                                        .foregroundStyle(.white)
//                                        .padding(.bottom, 30)
//                                    Spacer()
//
//                                }

//                                    if questionEnCours == 0 {
    


//                                    }
//                                else if questionEnCours == 2 {
//                                        ForEach(question2.reponses) { bonneReponse2Cat1Sous1 in
//
//                                            ReponsesExtractedView(tableauQuestions: $question2, questionChoisie: $questionEnCours, indexChoisi: $selectedIndex, question: bonneReponse2Cat1Sous1)
//
//                                            /*      VStack{
//
//                                             Button(action: {
//                                             print("pressed")
//                                             if bonneReponse2Cat1Sous1.reponse == "Végétalisme" && questionEnCours == 3{
//                                             //                                                    question2.bonnereponse = true
//                                             question2.score = 30
//
//
//                                             print(question2.score)
//                                             }
//                                             else {
//                                             //                                                    question2.bonnereponse = false
//                                             question2.score = 0
//
//
//                                             print(question2.score)
//                                             }
//
//                                             }, label: {
//                                             ZStack{
//                                             RoundedRectangle(cornerRadius: 20)
//                                             .fill(.white)
//                                             .frame(width: 300, height: 55)
//                                             .padding(7)
//                                             Text(bonneReponse2Cat1Sous1.reponse)
//                                             .font(.title3)
//                                             .fontWeight(.semibold)
//                                             .foregroundStyle(.black)
//                                             }
//                                             })
//                                             */
//                                        }
//
//                                    }
//                                    else if questionEnCours == 3 {
//                                        ForEach(question3.reponses) { bonneReponse3Cat1Sous1 in
//
//                                            ReponsesExtractedView(tableauQuestions: $question3, questionChoisie: $questionEnCours, indexChoisi: $selectedIndex, question: bonneReponse3Cat1Sous1)
//
//                                            /*  VStack{
//                                             /*
//                                              Button(action: {
//                                              print("pressed")
//                                              if bonneReponse3Cat1Sous1.reponse == question1.LaBonneReponse {
//                                              //                                                    question3.bonneReponse = true
//                                              question3.score = 30
//                                              print(question3.score)
//                                              }
//                                              else {
//                                              //                                                    question3.bonneReponse = false
//                                              question3.score = 0
//                                              print(question3.score)
//                                              }
//
//                                              }, label: {
//                                              ZStack{
//                                              RoundedRectangle(cornerRadius: 20)
//                                              .fill(.white)
//                                              .frame(width: 300,height: 55)
//                                              .padding(7)
//                                              Text(bonneReponse3Cat1Sous1.reponse)
//                                              .font(.title3)
//                                              .fontWeight(.semibold)
//                                              .foregroundStyle(.black)
//                                              }
//                                              })
//                                              */
//                                             } */
//
//                                        }
//                                    }



//                    if questionEnCours == 3 {
//                        NavigationLink(destination: Resultats()){
//                            //remettre l'aspect design du Button
//                            ZStack{
//                                if selectedIndex == nil {
//
//                                    RoundedRectangle(cornerRadius: 15)
//                                        .frame(width: 175,height: 50)
//                                        .foregroundStyle(Color.gray)
//                                        .disabled(true)
//                                    Text("Confirmer")
//                                        .font(.title2)
//                                        .padding()
//                                        .foregroundStyle(Color.white)
//
//
//                                } else {
//                                    RoundedRectangle(cornerRadius: 15)
//                                        .frame(width: 175,height: 50)
//                                        .foregroundStyle(Color("rougef"))
//                                    Text("Confirmer")
//                                        .font(.title2)
//                                        .padding()
//                                        .foregroundStyle(Color.white)
//                                }
//                            }
//                        }.padding(.vertical)
//                    } else {
    

//                            if questionEnCours < 3 && selectedIndex != nil{
//                                questionEnCours += 1
   
//                            }

                                
