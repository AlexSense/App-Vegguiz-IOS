//
//  PopUpAnswer.swift
//  IOS
//
//  Created by Apprenant97 on 02/02/2024.
//

import SwiftUI

struct PopUpAnswer: View {
    //1 - binging -> bool
    @Binding var popUp : Bool
    //binding -> Int?
    @Binding var selectedIndex : Int?
    //binding -> Int
    @Binding var questionEnCours : Int
   
    
    
    @EnvironmentObject var user: User
    
    var body: some View {
        NavigationStack{
            
            ZStack{ Rectangle()
                    .fill(.gray).opacity(/*@START_MENU_TOKEN@*/0.8/*@END_MENU_TOKEN@*/)
                    .ignoresSafeArea()
                
                
                RoundedRectangle(cornerRadius: 20)
                    .fill(Color("vertp"))
                    .frame(width: 350, height: 350)
                VStack{
                    //            if bonneReponse == true {
                    if user.selectedAnswer.bonneReponse {
                        VStack{
                            Image(systemName: "checkmark.seal.fill")
                                .resizable()
                                .frame(width: 100,height: 100)
                                .foregroundColor(Color.yellow)
                                .padding()
                            
                            if let bonneReponse = user.bonneReponse {
                                Text("Bien jouer, la bonne réponse était \("\"\(bonneReponse.reponse)\"")")
                                    .fontWeight(.semibold)
                                    .foregroundStyle(.white)
                                    .font(.title)
                                    .multilineTextAlignment(.center)
                                    .frame(width: 300)
                            }
                        }
                    }
                    
                    
                    else {
                        VStack{
                            Image(systemName: "xmark.seal.fill")
                                .resizable()
                                .frame(width: 100,height: 100)
                                .foregroundColor(Color.red)
                                .padding()
                            if let bonneReponse = user.bonneReponse {
                                Text("Dommage, la bonne réponse était \("\"\(bonneReponse.reponse)\"")")
                                    .fontWeight(.semibold)
                                    .foregroundStyle(.white)
                                    .font(.title)
                                    .multilineTextAlignment(.center)
                                    .frame(width: 300)
                            }
                        }
                        
                    }
                    if questionEnCours == 2 {
                        NavigationLink(destination: Resultats()){
                            
                            ZStack{
                                RoundedRectangle(cornerRadius: 20 )
                                    .frame(width: 100 , height: 70)
                                    .foregroundColor(Color.red)
                                Text("OK")
                                    .font(.title)
                                    .fontWeight(.bold)
                                    .foregroundColor(Color.white)
                                    .multilineTextAlignment(.center)
                                
                            }
                            
                        }
                        .onAppear {
                            selectedIndex = nil
                        }

                    }
                                            
                    Button(action: {
                        
                        //2 - toggle le bool
                        popUp = false
                        //coller condition if
                        if questionEnCours < 3 && selectedIndex != nil
                        {
                            questionEnCours += 1
                            print(questionEnCours)
                        }
                        
                        if let userBonneReponse =  user.bonneReponse {
                            user.progression.pts += 10
                        }
                        //binding -> nil
                        selectedIndex = nil
                        
                        //                                                print(selectedIndex)
                        
                    }, label: {
                        if questionEnCours < 2 {
                            ZStack{
                                RoundedRectangle(cornerRadius: 20 )
                                    .frame(width: 100 , height: 70)
                                    .foregroundColor(Color.red)
                                Text("OK")
                                    .font(.title)
                                    .fontWeight(.bold)
                                    .foregroundColor(Color.white)
                                    .multilineTextAlignment(.center)
                                
                                
                                
                            }.padding()
                        }
                    })
                }
            }
            
        }
    }
}

#Preview {
    //3 - .constant(false), .constant(1)
    PopUpAnswer(popUp: .constant(false), selectedIndex: .constant(1), questionEnCours: .constant(1))
        .environmentObject( User(name: "Toto", email: "toto@gmail.com", motDePasse: "666", imageprofil: "toto.img", progression: Jauge(ptsmax: 200, ptsrestants: 200, pts: 0), selectedAnswer: Reponse(reponse: "", bonneReponse: false)))
    
}
