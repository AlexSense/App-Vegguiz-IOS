//
//  Bons.swift
//  IOS
//
//  Created by Apprenant97 on 29/01/2024.
//

import SwiftUI

struct BonsView: View {
    
    @EnvironmentObject var user: User
    
    var body: some View {
        NavigationStack{
            ZStack{
                LinearGradient(colors: [Color("rougef").opacity(0.5), Color("orangeo").opacity(0.5), Color.yellow.opacity(0.5)], startPoint: .topTrailing, endPoint: .bottomLeading ).ignoresSafeArea( edges: .top)
                VStack{
                    
                    NavigationLink {
                        PageParametres()
                    } label: {
                        ProgressionUser()
                    }
                    
                    ZStack{
                        
                        
                        RoundedRectangle(cornerRadius: 15.0)
                            .fill(Color("rougef").opacity(0.4))
                            .frame(width: 250,height: 70)
                        Text("Vos Bons d'achat")
                            .font(.title)
                        
                    }
                    NavigationLink(destination: BonsPrecis()){
                        HStack{
                            
                            
                            
                            Image("couponRouge")
                                .resizable()
                                .scaledToFit()
                                .frame(height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/)
                                .opacity(0.8)
                            ZStack{
                                RoundedRectangle(cornerRadius: 15.0)
                                    .fill(Color("vertp").opacity(0.9))
                                    .frame(width: 250, height: 70)
                                Text("\(3)€ Bio c'est bon")
                                    .font(.title3)
                                    .fontWeight(.semibold)
                                    .foregroundStyle(.white)
                            }
                            
                        }
                    }
                    
                    
                    RoundedRectangle(cornerRadius: 90)
                        .padding(.bottom)
                        .frame(width: 250,height: 20.0)
                        .opacity(0.6)
                    
                    
                    ZStack{
                        
                        
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color("rougef"))
                            .opacity(0.40)
                            .padding(.horizontal)
                        
                        
                       
                            
                            
                            VStack{
                                ScrollView{
                                
                             
                                
                                HStack{
                                    
                                    Image("Coupon")
                                        .resizable()
                                        .opacity(0.6)
                                        .scaledToFit()
                                        .frame(height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/)
                                    
                                    ZStack{
                                        
                                        RoundedRectangle(cornerRadius: 15.0)
                                            .fill(.gray.opacity(0.7))
                                            .frame(width: 230, height: 70)
                                        Text("\(3)€ \("Legumaniac")")
                                            .font(.headline)
                                            .fontWeight(.semibold)
                                            .foregroundStyle(.white)
                                    }
                                }
                                
                                HStack{
                                    Image("Coupon")
                                        .resizable()
                                        .opacity(0.6)
                                        .scaledToFit()
                                        .frame(height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/)
                                    
                                    ZStack{
                                        RoundedRectangle(cornerRadius: 15.0)
                                            .fill(.gray.opacity(0.7))
                                            .frame(width: 230, height: 70)
                                        Text("\(3)€ TofuTastique")
                                            .font(.headline)
                                            .fontWeight(.semibold)
                                            .foregroundStyle(.white)
                                    }
                                }
                                HStack{
                                    Image("Coupon")
                                        .resizable()
                                        .opacity(0.6)
                                        .scaledToFit()
                                        .frame(height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/)
                                    
                                    ZStack{
                                        RoundedRectangle(cornerRadius: 15.0)
                                            .fill(.gray.opacity(0.9))
                                            .frame(width: 230, height: 70)
                                        Text("\(3)€ Courgettopia")
                                            .font(.headline)
                                            .fontWeight(.semibold)
                                            .foregroundStyle(.white)
                                        
                                    }
                                }
                                HStack{
                                    VStack{
                                        Text("Nos partenaires:")
                                            .font(.title)
                                            .padding(.leading, 25)
                                        HStack(alignment: .center){
                                            Image("logo1")
                                                .resizable()
                                                .frame(width: 75,height: 75)
                                            Image("logo2")
                                                .resizable()
                                                .frame(width: 75,height: 50)
                                            Image("logo3")
                                                .resizable()
                                                .frame(width: 75,height: 50)
                                            Image("logo4")
                                                .resizable()
                                                .frame(width: 75,height: 75)
                                        }.padding(.leading, 20)
                                    }
                                    Spacer()
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
#Preview {
    BonsView()
        .environmentObject( User(name: "Thomas", email: "thomas@gmail.com", motDePasse: "666", imageprofil: "salad", progression: Jauge(ptsmax: 200, ptsrestants: 200, pts: 0), selectedAnswer: Reponse(reponse: "", bonneReponse: false)))
}
