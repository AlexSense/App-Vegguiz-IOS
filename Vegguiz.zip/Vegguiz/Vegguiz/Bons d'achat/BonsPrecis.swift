//
//  BonsPrecis.swift
//  IOS
//
//  Created by Apprenant97 on 29/01/2024.
//

import SwiftUI

struct BonsPrecis: View {
    var body: some View {
        
        ZStack{
            LinearGradient(colors: [Color("rougef").opacity(0.5), Color("orangeo").opacity(0.5), Color.yellow.opacity(0.5)], startPoint: .topTrailing, endPoint: .bottomLeading ).ignoresSafeArea()
            
            
            Spacer()
            
            ZStack{
                
                
                RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                    .fill(Color("rougef"))
                    .opacity(0.3)
                    .padding()
                
                VStack{
                    
                    
                    
                    Text("BIO C'EST BON")
                        .fontWeight(.semibold)
                        .padding()
                        .foregroundStyle(Color.white)
                        .background(Color("vertp"))
                        .font(.system(size: 30))
                        .cornerRadius(15)
                        .padding(.top, 30)
                    
                    
                    
                    
                    
                    Spacer()
                    
                    ZStack{
                        
                        RoundedRectangle(cornerRadius: 10)
                            .frame(width: 335, height: 210)
                            .foregroundStyle(Color.white.opacity(0.80))
                            .padding()
                        
                        
                        
                        Image(systemName: "barcode")
                            .resizable()
                            .frame(width: 280, height: 150)
                            .padding()
                        
                    }
                    
                    Spacer()
                    
                    Text(" 3 € ")
                        .fontWeight(.medium)
                        .multilineTextAlignment(.center)
                        .padding(15)
                        .foregroundStyle(Color.white)
                        .background(Color("vertp"))
                        .font(.system(size: 35))
                        .cornerRadius(20)
                    
                    Spacer()
                    
                    
                    Text("Bon d'achat valable chez nos partenaire, valable du 11/01/1024 au 2/02/2024")
                        .fontWeight(.regular)
                        .foregroundColor(Color.white)
                        .multilineTextAlignment(.center)
                        .font(.system(size: 30))
                        .padding(.bottom, 40)
                        .padding()
                    
                    Spacer()
                }
            }
        }
    }
}
#Preview {
    BonsPrecis()
}
